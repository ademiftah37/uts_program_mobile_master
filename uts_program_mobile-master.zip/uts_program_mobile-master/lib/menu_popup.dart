import 'package:flutter/material.dart';
import 'main.dart'; // for HomePage
import 'profile_page.dart'; // for ProfilePage

class MenuPopup {
  static void show(BuildContext context) {
    showDialog(
      context: context,
      barrierDismissible: true,
      barrierColor: Colors.black54,
      builder: (BuildContext context) {
        final screenH = MediaQuery.of(context).size.height;
        final screenW = MediaQuery.of(context).size.width;

        return Dialog(
          backgroundColor: Colors.transparent,
          insetPadding: const EdgeInsets.symmetric(horizontal: 12.0, vertical: 18.0),
          child: SizedBox(
            width: screenW,
            height: screenH * 0.65,
            child: Column(
              children: [

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.fromLTRB(16, 16, 12, 14),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.vertical(top: Radius.circular(12)),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 36,
                                height: 36,
                                decoration: const BoxDecoration(
                                  shape: BoxShape.circle,
                                  image: DecorationImage(
                                    image: AssetImage('assets/logo_inaklug.png'),
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 10),
                              const Text(
                                'Inaklug',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 16,
                                ),
                              ),
                            ],
                          ),
                          IconButton(
                            icon: const Icon(Icons.close, color: Colors.black54),
                            onPressed: () => Navigator.pop(context),
                          ),
                        ],
                      ),

                      const SizedBox(height: 6),
                      const Divider(height: 1, color: Colors.black12),

                      const SizedBox(height: 14),


                      _menuItem(context, 'HOME', onTap: () {
                        Navigator.pop(context); // close popup
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (_) => HomePage()),
                        );
                      }),

                      _menuItem(context, 'TENTANG KAMI', onTap: () {
                        Navigator.pop(context); // close popup
                        Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(builder: (_) => ProfilePage()),
                        );
                      }),

                      _menuItem(context, 'LAYANAN KAMI', onTap: () {
                        Navigator.pop(context);
                      }),

                      _menuItem(context, 'ARTIKEL', onTap: () {
                        Navigator.pop(context);
                      }),

                      _menuItem(context, 'HUBUNGI KAMI', onTap: () {
                        Navigator.pop(context);
                      }),

                      const SizedBox(height: 6),
                    ],
                  ),
                ),


              ],
            ),
          ),
        );
      },
    );
  }

  static Widget _menuItem(BuildContext context, String title, {required VoidCallback onTap}) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0, bottom: 8.0, left: 4.0),
      child: InkWell(
        onTap: onTap,
        child: Text(
          title,
          style: const TextStyle(
            fontSize: 15,
            height: 1.1,
            letterSpacing: 0.3,
            color: Colors.black87,
          ),
        ),
      ),
    );
  }
}

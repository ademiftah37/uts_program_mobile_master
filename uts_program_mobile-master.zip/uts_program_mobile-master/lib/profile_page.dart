import 'package:flutter/material.dart';
import 'menu_popup.dart';


class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  Widget _topBar() {
    return Container(
      height: kToolbarHeight,
      width: double.infinity,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF6A1B9A), Color(0xFF3F51B5)],
          begin: Alignment.centerLeft,
          end: Alignment.centerRight,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12.0),
        child: Row(
          children: [
            Container(
              width: 36,
              height: 36,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                image: DecorationImage(
                  image: AssetImage('assets/logo_inaklug.png'),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              'Inaklug',
              style: TextStyle(
                color: Colors.white,
                fontSize: 18,
                fontWeight: FontWeight.w600,
              ),
            ),
            const Spacer(),
            InkWell(
              onTap: () => MenuPopup.show(context), // gunakan popup full-height
              child: const Padding(
                padding: EdgeInsets.all(8.0),
                child: Icon(Icons.menu, color: Colors.white, size: 24),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12.0),
      child: Text(
        text,
        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
    );
  }

  Widget _paragraph(String text) {
    return Text(
      text,
      textAlign: TextAlign.justify,
      style: const TextStyle(fontSize: 15, height: 1.6),
    );
  }

  Widget _imageWithCaption(String assetPath, {double height = 130}) {
    return Padding(
      padding: const EdgeInsets.only(top: 8.0, bottom: 8.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Image.asset(
          assetPath,
          height: height,
          width: double.infinity,
          fit: BoxFit.cover,
          errorBuilder: (c, e, s) => Container(height: height, color: Colors.grey[300]),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      drawer: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const UserAccountsDrawerHeader(
              accountName: Text('Canatantio'),
              accountEmail: Text('41822020002@student.univ.ac.id'),
              currentAccountPicture: CircleAvatar(
                backgroundImage: AssetImage('assets/logo_inaklug.png'),
                backgroundColor: Colors.white,
              ),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Color(0xFF6A1B9A), Color(0xFF3F51B5)],
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.home),
              title: const Text('Beranda'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: const Icon(Icons.info),
              title: const Text('Tentang Kami'),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),

      body: SafeArea(
        child: Column(
          children: [
            // fixed header (same as homepage)
            _topBar(),

            // scrollable content below header
            Expanded(
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    // hero image with overlay title
                    Stack(
                      children: [
                        Image.asset(
                          'assets/dresden2.jpg',
                          width: double.infinity,
                          height: 170,
                          fit: BoxFit.cover,
                          errorBuilder: (c, e, s) => Container(height: 170, color: Colors.grey[300]),
                        ),
                        const Positioned(
                          left: 16,
                          bottom: 14,
                          child: Text(
                            'Tentang Kami',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 22,
                              fontWeight: FontWeight.w600,
                              shadows: [
                                Shadow(color: Colors.black45, blurRadius: 6, offset: Offset(0, 2))
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),

                    // main content - matches homepage padding
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          _sectionTitle('PROFIL'),
                          _paragraph(
                            'Didirikan pada tahun 2018, INAKLUG merupakan konsultan pendidikan internasional yang berpengalaman, terpercaya, dan memiliki jaringan luas untuk membantu mahasiswa Indonesia meraih pendidikan di luar negeri. Kami menyediakan layanan konsultasi, bimbingan, dan dukungan administratif untuk calon mahasiswa.',
                          ),
                          _imageWithCaption('assets/visi.png', height: 120),

                          _sectionTitle('Visi'),
                          _paragraph(
                            'Membangun Sumber Daya Indonesia yang memiliki daya saing tinggi dan tangguh secara internasional untuk menghadapi era globalisasi serta menjadi pemimpin masa depan yang mandiri, profesional, dan inovatif.',
                          ),
                          _imageWithCaption('assets/misi.png', height: 120),

                          _sectionTitle('Misi'),
                          _paragraph(
                            '1. Mengembangkan produk edukasi dan layanan konsultasi berkualitas.\n'
                                '2. Memberikan pendampingan menyeluruh bagi pelajar yang ingin studi di luar negeri.\n'
                                '3. Meningkatkan kompetensi tim agar selalu memberikan pelayanan terbaik.',
                          ),

                          const SizedBox(height: 40),

                          // separator + Hubungi Kami (same as homepage)
                          const Divider(thickness: 0.6, color: Colors.black26, indent: 40, endIndent: 40),
                          const SizedBox(height: 25),

                          const Center(
                            child: Text(
                              'Hubungi Kami',
                              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                            ),
                          ),
                          const SizedBox(height: 10),
                          const Center(
                            child: Text(
                              'Kantor Pusat',
                              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w500),
                            ),
                          ),
                          const SizedBox(height: 8),
                          const Padding(
                            padding: EdgeInsets.symmetric(horizontal: 28.0),
                            child: Text(
                              'Meruya Sel., Kec. Kembangan, Jakarta,\nDaerah Khusus Ibukota Jakarta\n11650',
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 14, height: 1.4),
                            ),
                          ),
                          const SizedBox(height: 10),
                          const Center(
                            child: Text(
                              'Phone: 08119852020',
                              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500, color: Colors.black87),
                            ),
                          ),

                          // buttons same style as homepage
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 40.0, vertical: 20.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: () {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Membuka lokasi kantor...')),
                                      );
                                    },
                                    style: ElevatedButton.styleFrom(
                                      padding: const EdgeInsets.symmetric(vertical: 14),
                                      backgroundColor: const Color(0xFF3F51B5),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                                    ),
                                    child: const Text('Lokasi Kami', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
                                  ),
                                ),
                                const SizedBox(width: 20),
                                Expanded(
                                  child: ElevatedButton(
                                    onPressed: () {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        const SnackBar(content: Text('Membuka form kirim pesan...')),
                                      );
                                    },
                                    style: ElevatedButton.styleFrom(
                                      padding: const EdgeInsets.symmetric(vertical: 14),
                                      backgroundColor: const Color(0xFF6A1B9A),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
                                    ),
                                    child: const Text('Kirim Pesan', style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600)),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          const SizedBox(height: 40),
                          // end of padded content
                        ],
                      ),
                    ),

                    // footer moved outside the padded content so it is full width like homepage
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 14.0),
                      decoration: const BoxDecoration(
                        gradient: LinearGradient(
                          colors: [Color(0xFF6A1B9A), Color(0xFF3F51B5)],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                      ),
                      child: const Center(
                        child: Text(
                          'Canatantio Togapna Abibi\n41822020002',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 13,
                            height: 1.4,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
